# iPhone Virtual (React + Vite)

Simulasi iPhone interaktif di browser: lock screen, home screen, wallpaper, status bar, jam,
14 aplikasi dan animasi transisi. Ini proyek demo dan tidak terhubung ke akun atau data asli.

## Menjalankan
```bash
npm install
npm run dev      # buka http://localhost:5173
npm run build    # hasil di folder dist
npm run preview
```

## Catatan
- Pesan, Catatan, Kalender, dan Pengaturan disimpan di localStorage browser (kunci berawalan `vi-`).
- Foto dan hasil Kamera hanya ada di memori halaman dan hilang saat dimuat ulang.
- WhatsApp, Instagram, X, Spotify, YouTube, Maps, dan Safari hanya membuka situs resmi di tab baru.
- Kamera membutuhkan HTTPS atau localhost, serta izin dari pengguna.
