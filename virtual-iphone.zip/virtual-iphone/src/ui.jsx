import { useContext } from 'react'
import { Ctx } from './ctx'

export function Page({ title, back, right, children, flush }) {
  const { close } = useContext(Ctx)
  return (
    <div className="page">
      <header className="nav">
        <button className="navbtn" onClick={back || close}>‹ {back ? 'Kembali' : 'Beranda'}</button>
        <h1>{title}</h1>
        <div className="navr">{right}</div>
      </header>
      <div className={`body ${flush ? 'flush' : ''}`}>{children}</div>
    </div>
  )
}

export function Toggle({ on, onChange }) {
  return (
    <button role="switch" aria-checked={on} className={`tg ${on ? 'on' : ''}`} onClick={() => onChange(!on)}>
      <i />
    </button>
  )
}
