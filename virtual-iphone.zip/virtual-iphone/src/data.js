export const WALLPAPERS = [
  { name: 'Aurora', css: 'linear-gradient(160deg,#0f2027,#2c5364 45%,#8e54e9)' },
  { name: 'Senja', css: 'linear-gradient(160deg,#ff9966,#ff5e62 50%,#4a1c6b)' },
  { name: 'Laut', css: 'linear-gradient(160deg,#0575e6,#00c9a7)' },
  { name: 'Malam', css: 'linear-gradient(160deg,#0f0c29,#302b63,#24243e)' },
  { name: 'Sakura', css: 'linear-gradient(160deg,#ffafbd,#ffc3a0 50%,#c471ed)' },
  { name: 'Hutan', css: 'linear-gradient(160deg,#134e5e,#71b280)' }
]

export const CONTACTS = [
  { id: 'alya', name: 'Alya (demo)' },
  { id: 'budi', name: 'Budi (demo)' },
  { id: 'tim', name: 'Tim Proyek (demo)' }
]

export const REPLIES = ['Siap!', 'Oke, noted 👍', 'Nanti kukabari ya', 'Haha iya', 'Sip, terima kasih', 'Boleh banget']

export const PHOTO_SEED = [
  ['🌅', '#ff9a9e,#fad0c4'], ['🏝️', '#43cea2,#185a9d'], ['🌃', '#0f2027,#2c5364'],
  ['🌸', '#ffafbd,#ffc3a0'], ['🏔️', '#8e9eab,#cfd9df'], ['🌲', '#134e5e,#71b280'],
  ['🌊', '#2193b0,#6dd5ed'], ['🌇', '#f12711,#f5af19'], ['🌌', '#41295a,#2f0743']
].map(([emoji, g], i) => ({ id: i + 1, emoji, bg: `linear-gradient(135deg,${g})`, fav: false }))
