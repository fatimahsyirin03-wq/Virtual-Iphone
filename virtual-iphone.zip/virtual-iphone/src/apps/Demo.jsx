import { useState, useEffect, useRef, useContext } from 'react'
import { Ctx } from '../ctx.js'
import { Page, Toggle } from '../ui.jsx'
import { useLocal } from '../hooks.js'
import { WALLPAPERS, CONTACTS, REPLIES } from '../data.js'

const pick = (a) => a[Math.floor(Math.random() * a.length)]

/* ---------------- Pesan ---------------- */
export function Messages() {
  const [th, setTh] = useLocal('vi-msgs', {
    alya: [{ me: false, t: 'Halo! Ini pesan demo 👋' }],
    budi: [],
    tim: [{ me: false, t: 'Rapat besok jam 10 ya (demo)' }]
  })
  const [id, setId] = useState(null)
  const [txt, setTxt] = useState('')
  const end = useRef(null)
  useEffect(() => { end.current?.scrollIntoView() }, [th, id])
  const add = (cid, m) => setTh((p) => ({ ...p, [cid]: [...(p[cid] || []), m] }))
  const send = (e) => {
    e.preventDefault()
    const t = txt.trim()
    if (!t) return
    const cid = id
    add(cid, { me: true, t })
    setTxt('')
    setTimeout(() => add(cid, { me: false, t: pick(REPLIES) }), 900)
  }
  const c = CONTACTS.find((x) => x.id === id)
  if (c)
    return (
      <Page title={c.name} back={() => setId(null)} flush>
        <div className="chatwrap">
          <div className="chat">
            {(th[id] || []).map((m, i) => (
              <div key={i} className={`bub ${m.me ? 'me' : ''}`}>{m.t}</div>
            ))}
            <div ref={end} />
          </div>
          <form className="compose" onSubmit={send}>
            <input value={txt} onChange={(e) => setTxt(e.target.value)} placeholder="Ketik pesan" />
            <button className="btn" type="submit">Kirim</button>
          </form>
        </div>
      </Page>
    )
  return (
    <Page title="Pesan">
      {CONTACTS.map((x) => {
        const last = (th[x.id] || []).slice(-1)[0]
        return (
          <button key={x.id} className="row" onClick={() => setId(x.id)}>
            <span className="avatar">{x.name[0]}</span>
            <span>
              <b>{x.name}</b>
              <br />
              <small className="mut">{last ? last.t : 'Belum ada pesan'}</small>
            </span>
          </button>
        )
      })}
      <p className="note">Kontak dan balasan otomatis hanyalah simulasi. Tidak ada pesan nyata yang dikirim.</p>
    </Page>
  )
}

/* ---------------- Catatan ---------------- */
export function Notes() {
  const [notes, setNotes] = useLocal('vi-notes', [
    { id: 1, text: 'Selamat datang\nCatatan ini hanya disimpan di browser Anda.' }
  ])
  const [cur, setCur] = useState(null)
  const [q, setQ] = useState('')
  const add = () => {
    const n = { id: Date.now(), text: '' }
    setNotes((p) => [n, ...p])
    setCur(n.id)
  }
  const edit = (v) => setNotes((p) => p.map((n) => (n.id === cur ? { ...n, text: v } : n)))
  const del = () => { setNotes((p) => p.filter((n) => n.id !== cur)); setCur(null) }
  const note = notes.find((n) => n.id === cur)
  if (note)
    return (
      <Page title="Catatan" back={() => (note.text.trim() ? setCur(null) : del())} right={<button onClick={del} aria-label="Hapus">🗑</button>}>
        <textarea autoFocus rows={16} value={note.text} onChange={(e) => edit(e.target.value)} placeholder="Tulis sesuatu…" />
      </Page>
    )
  const list = notes.filter((n) => n.text.toLowerCase().includes(q.toLowerCase()))
  return (
    <Page title="Catatan" right={<button onClick={add} aria-label="Catatan baru">＋</button>}>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari catatan" style={{ marginBottom: 12 }} />
      {list.length === 0 && <p className="mut">Belum ada catatan.</p>}
      {list.map((n) => {
        const [t, ...rest] = n.text.split('\n')
        return (
          <button key={n.id} className="row" onClick={() => setCur(n.id)}>
            <span>
              <b>{t || 'Catatan baru'}</b>
              <br />
              <small className="mut">{rest.join(' ').slice(0, 50) || 'Tidak ada teks tambahan'}</small>
            </span>
          </button>
        )
      })}
    </Page>
  )
}

/* ---------------- Foto ---------------- */
const sty = (p) => (p.src ? { backgroundImage: `url(${p.src})` } : { background: p.bg })

export function Gallery() {
  const { photos, setPhotos } = useContext(Ctx)
  const [sel, setSel] = useState(null)
  const [favOnly, setFavOnly] = useState(false)
  const upload = (e) => {
    ;[...e.target.files].forEach((f) => {
      const r = new FileReader()
      r.onload = () => setPhotos((p) => [{ id: Date.now() + Math.random(), src: r.result, fav: false }, ...p])
      r.readAsDataURL(f)
    })
    e.target.value = ''
  }
  const toggleFav = (id) => setPhotos((p) => p.map((x) => (x.id === id ? { ...x, fav: !x.fav } : x)))
  const remove = (id) => { setPhotos((p) => p.filter((x) => x.id !== id)); setSel(null) }
  const shown = photos.filter((p) => !favOnly || p.fav)
  const cur = photos.find((p) => p.id === sel)
  return (
    <>
      <Page
        title="Foto"
        flush
        right={
          <label className="navbtn" style={{ cursor: 'pointer' }}>
            ＋<input type="file" accept="image/*" multiple hidden onChange={upload} />
          </label>
        }
      >
        <div className="tabs">
          <button className={!favOnly ? 'on' : ''} onClick={() => setFavOnly(false)}>Semua</button>
          <button className={favOnly ? 'on' : ''} onClick={() => setFavOnly(true)}>Favorit</button>
        </div>
        <div className="pgrid">
          {shown.map((p) => (
            <button key={p.id} className="thumb" style={sty(p)} onClick={() => setSel(p.id)} aria-label="Buka foto">
              {!p.src && p.emoji}
              {p.fav && <span className="heart">♥</span>}
            </button>
          ))}
        </div>
        <p className="note" style={{ margin: 14 }}>Foto yang Anda tambah atau ambil hanya ada di memori browser dan tidak diunggah ke server mana pun.</p>
      </Page>
      {cur && (
        <div className="viewer">
          <div className="vbar">
            <button onClick={() => setSel(null)}>‹ Kembali</button>
            <span>
              <button onClick={() => toggleFav(cur.id)}>{cur.fav ? '♥' : '♡'}</button>
              <button onClick={() => remove(cur.id)}>🗑</button>
            </span>
          </div>
          <div className="big" style={sty(cur)}>{!cur.src && cur.emoji}</div>
        </div>
      )}
    </>
  )
}

/* ---------------- Kamera ---------------- */
export function Camera() {
  const { setPhotos, close } = useContext(Ctx)
  const vid = useRef(null)
  const stream = useRef(null)
  const [err, setErr] = useState('')
  const [flash, setFlash] = useState(false)
  const [face, setFace] = useState('user')
  const [last, setLast] = useState(null)

  useEffect(() => {
    let dead = false
    setErr('')
    if (!navigator.mediaDevices?.getUserMedia) {
      setErr('Browser ini tidak mendukung akses kamera (butuh HTTPS atau localhost).')
      return
    }
    navigator.mediaDevices
      .getUserMedia({ video: { facingMode: face }, audio: false })
      .then((st) => {
        if (dead) { st.getTracks().forEach((t) => t.stop()); return }
        stream.current = st
        if (vid.current) vid.current.srcObject = st
      })
      .catch(() => setErr('Izin kamera ditolak atau kamera tidak tersedia.'))
    return () => {
      dead = true
      stream.current?.getTracks().forEach((t) => t.stop())
    }
  }, [face])

  const shot = () => {
    const el = vid.current
    if (!el || !el.videoWidth) return
    const c = document.createElement('canvas')
    c.width = el.videoWidth
    c.height = el.videoHeight
    c.getContext('2d').drawImage(el, 0, 0)
    const src = c.toDataURL('image/jpeg', 0.85)
    setPhotos((p) => [{ id: Date.now(), src, fav: false }, ...p])
    setLast(src)
    setFlash(true)
    setTimeout(() => setFlash(false), 150)
  }

  return (
    <div className="cam">
      <button className="camx" onClick={close} aria-label="Tutup">✕</button>
      {err ? (
        <div className="camerr">{err}</div>
      ) : (
        <video ref={vid} autoPlay playsInline muted style={{ transform: face === 'user' ? 'scaleX(-1)' : 'none' }} />
      )}
      {flash && <div className="flash" />}
      <div className="camctl">
        <div className="lastp" style={last ? { backgroundImage: `url(${last})` } : {}} />
        <button className="shutter" onClick={shot} aria-label="Ambil foto" />
        <button className="flip" onClick={() => setFace((f) => (f === 'user' ? 'environment' : 'user'))} aria-label="Balik kamera">🔄</button>
      </div>
    </div>
  )
}

/* ---------------- Pengaturan ---------------- */
const Row = ({ label, children }) => (
  <div className="set">
    <span>{label}</span>
    {children}
  </div>
)

export function Settings() {
  const { s, set, reset } = useContext(Ctx)
  return (
    <Page title="Pengaturan">
      <div className="grp">
        <Row label="✈️ Mode Pesawat"><Toggle on={s.air} onChange={(v) => set('air', v)} /></Row>
        <Row label="📶 Wi-Fi"><Toggle on={s.wifi} onChange={(v) => set('wifi', v)} /></Row>
        <Row label="🔵 Bluetooth"><Toggle on={s.bt} onChange={(v) => set('bt', v)} /></Row>
      </div>
      <div className="grp">
        <Row label="🌙 Mode Gelap"><Toggle on={s.dark} onChange={(v) => set('dark', v)} /></Row>
        <Row label="☀️ Kecerahan">
          <input type="range" min="20" max="100" value={s.bright} onChange={(e) => set('bright', +e.target.value)} style={{ width: 140, padding: 0 }} />
        </Row>
      </div>
      <div className="grp">
        <div className="set" style={{ display: 'block' }}>
          <div style={{ marginBottom: 10 }}>🖼️ Wallpaper</div>
          <div className="swatches">
            {WALLPAPERS.map((w, i) => (
              <button key={w.name} title={w.name} className={s.wall === i ? 'on' : ''} style={{ background: w.css }} onClick={() => set('wall', i)} />
            ))}
          </div>
        </div>
      </div>
      <div className="grp">
        <div className="set" style={{ display: 'block' }}>
          <div style={{ marginBottom: 8 }}>📱 Nama perangkat</div>
          <input value={s.name} maxLength={24} onChange={(e) => set('name', e.target.value)} />
        </div>
        <Row label="Versi"><span className="mut">Demo 1.0</span></Row>
      </div>
      <button className="btn danger" onClick={() => window.confirm('Hapus semua data demo (pesan, catatan, agenda, pengaturan)?') && reset()}>
        Reset data demo
      </button>
      <p className="note">Semua pengaturan hanya mengubah simulasi ini dan disimpan di browser Anda. Tidak ada koneksi ke Apple ID atau akun nyata.</p>
    </Page>
  )
}

/* ---------------- Kalender ---------------- */
const key = (d) => `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`

export function Calendar() {
  const [ev, setEv] = useLocal('vi-events', {})
  const t = new Date()
  const [m, setM] = useState(new Date(t.getFullYear(), t.getMonth(), 1))
  const [sel, setSel] = useState(key(t))
  const [txt, setTxt] = useState('')
  const first = m.getDay()
  const days = new Date(m.getFullYear(), m.getMonth() + 1, 0).getDate()
  const cells = [...Array(first).fill(null), ...Array.from({ length: days }, (_, i) => new Date(m.getFullYear(), m.getMonth(), i + 1))]
  const shift = (n) => setM(new Date(m.getFullYear(), m.getMonth() + n, 1))
  const add = (e) => {
    e.preventDefault()
    if (!txt.trim()) return
    setEv((p) => ({ ...p, [sel]: [...(p[sel] || []), txt.trim()] }))
    setTxt('')
  }
  const del = (i) => setEv((p) => ({ ...p, [sel]: p[sel].filter((_, j) => j !== i) }))
  return (
    <Page title="Kalender">
      <div className="cmonth">
        <button className="navbtn" onClick={() => shift(-1)}>‹</button>
        <b>{m.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' })}</b>
        <button className="navbtn" onClick={() => shift(1)} style={{ textAlign: 'right' }}>›</button>
      </div>
      <div className="cgrid mut">{['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'].map((d) => <small key={d}>{d}</small>)}</div>
      <div className="cgrid">
        {cells.map((d, i) =>
          d ? (
            <button
              key={i}
              className={`day ${key(d) === key(t) ? 'today' : ''} ${key(d) === sel ? 'sel' : ''} ${ev[key(d)]?.length ? 'has' : ''}`}
              onClick={() => setSel(key(d))}
            >
              {d.getDate()}
            </button>
          ) : (
            <span key={i} />
          )
        )}
      </div>
      <h3 style={{ margin: '18px 0 8px' }}>Agenda</h3>
      {(ev[sel] || []).map((e, i) => (
        <div key={i} className="row" style={{ cursor: 'default' }}>
          <span>{e}</span>
          <button className="navbtn" style={{ marginLeft: 'auto' }} onClick={() => del(i)} aria-label="Hapus">✕</button>
        </div>
      ))}
      {!(ev[sel] || []).length && <p className="mut">Tidak ada acara.</p>}
      <form className="compose" onSubmit={add} style={{ padding: '8px 0', border: 0 }}>
        <input value={txt} onChange={(e) => setTxt(e.target.value)} placeholder="Tambah acara" />
        <button className="btn" type="submit">Tambah</button>
      </form>
    </Page>
  )
}

/* ---------------- Telepon (simulasi) ---------------- */
export function Phone() {
  const [n, setN] = useState('')
  const [call, setCall] = useState(false)
  const [sec, setSec] = useState(0)
  useEffect(() => {
    if (!call) return
    setSec(0)
    const t = setInterval(() => setSec((x) => x + 1), 1000)
    return () => clearInterval(t)
  }, [call])
  const mm = String(Math.floor(sec / 60)).padStart(2, '0')
  const ss = String(sec % 60).padStart(2, '0')
  return (
    <>
      <Page title="Telepon">
        <div className="numdisp">
          {n || <span className="mut">Ketik nomor</span>}
          {n && <button className="navbtn" onClick={() => setN(n.slice(0, -1))} aria-label="Hapus angka"> ⌫</button>}
        </div>
        <div className="keys">
          {'123456789*0#'.split('').map((k) => (
            <button key={k} className="key" onClick={() => setN(n + k)}>{k}</button>
          ))}
          <span />
          <button className="key callbtn" disabled={!n} onClick={() => setCall(true)} aria-label="Panggil">📞</button>
        </div>
        <p className="note">Telepon ini hanya simulasi. Tidak ada panggilan nyata yang dilakukan.</p>
      </Page>
      {call && (
        <div className="calling">
          <div className="avatar" style={{ width: 90, height: 90, fontSize: 36 }}>#</div>
          <h2 style={{ margin: '10px 0 0' }}>{n}</h2>
          <div>{sec < 2 ? 'Memanggil… (simulasi)' : `${mm}:${ss}`}</div>
          <button className="key endbtn" onClick={() => setCall(false)} aria-label="Akhiri">✕</button>
        </div>
      )}
    </>
  )
}
