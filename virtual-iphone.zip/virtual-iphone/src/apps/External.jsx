import { useState } from 'react'
import { Page } from '../ui.jsx'

const openTab = (u) => window.open(u, '_blank', 'noopener,noreferrer')

// Halaman peluncur: tidak ada data akun. Hanya membuka situs resmi di tab baru.
function Launcher({ title, bg, glyph, url, desc, placeholder, search, links = [] }) {
  const [q, setQ] = useState('')
  const go = (e) => {
    e.preventDefault()
    openTab(search && q.trim() ? search(q.trim()) : url)
  }
  return (
    <Page title={title}>
      <div className="hero" style={{ background: bg }}>
        <div className="g">{glyph}</div>
        <h2>{title}</h2>
        <p>{desc}</p>
      </div>
      <form onSubmit={go} className="lform">
        {search && <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={placeholder} />}
        <button className="btn" type="submit">{search && q.trim() ? 'Cari' : 'Buka'} di situs resmi ↗</button>
      </form>
      {links.map((l) => (
        <button key={l[0]} className="row" onClick={() => openTab(l[1])}>
          {l[0]}
          <span style={{ marginLeft: 'auto' }}>↗</span>
        </button>
      ))}
      <p className="note">
        Ini hanya tampilan demo. Aplikasi ini tidak terhubung ke akun atau data asli Anda. Tombol di atas membuka situs
        resmi di tab baru, karena situs tersebut tidak dapat ditampilkan di dalam bingkai.
      </p>
    </Page>
  )
}

export const WhatsApp = () => (
  <Launcher title="WhatsApp" glyph="💬" bg="linear-gradient(#5ff07e,#1fae4b)" url="https://web.whatsapp.com"
    desc="Buka WhatsApp Web di tab baru dan masuk dengan akun Anda sendiri di sana." />
)

export const Instagram = () => (
  <Launcher title="Instagram" glyph="📸" bg="linear-gradient(45deg,#f9a03f,#d62976 50%,#4f5bd5)" url="https://www.instagram.com"
    desc="Buka situs resmi Instagram di tab baru." />
)

export const XApp = () => (
  <Launcher title="X / Twitter" glyph="𝕏" bg="linear-gradient(#222,#000)" url="https://x.com"
    desc="Buka situs resmi X di tab baru." placeholder="Cari di X…"
    search={(q) => 'https://x.com/search?q=' + encodeURIComponent(q)} />
)

export const Spotify = () => (
  <Launcher title="Spotify" glyph="🎧" bg="linear-gradient(#1ed760,#118a3c)" url="https://open.spotify.com"
    desc="Buka Spotify Web Player di tab baru." placeholder="Cari lagu, artis, atau podcast…"
    search={(q) => 'https://open.spotify.com/search/' + encodeURIComponent(q)} />
)

export const YouTube = () => (
  <Launcher title="YouTube" glyph="▶️" bg="linear-gradient(#ff4e45,#c4150c)" url="https://www.youtube.com"
    desc="Cari dan tonton video di situs resmi YouTube." placeholder="Cari video…"
    search={(q) => 'https://www.youtube.com/results?search_query=' + encodeURIComponent(q)} />
)

export const Maps = () => (
  <Launcher title="Maps" glyph="🗺️" bg="linear-gradient(#6ee7a0,#4aa3ff)" url="https://www.google.com/maps"
    desc="Cari tempat atau rute di Google Maps (tab baru)." placeholder="Cari tempat atau alamat…"
    search={(q) => 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(q)} />
)

// Safari: input URL atau kata kunci. Hanya http(s) yang diizinkan.
const smart = (q) =>
  /^https?:\/\//i.test(q)
    ? q
    : /^[^\s]+\.[a-z]{2,}(\/.*)?$/i.test(q)
    ? 'https://' + q
    : 'https://www.google.com/search?q=' + encodeURIComponent(q)

export const Safari = () => (
  <Launcher title="Safari" glyph="🧭" bg="linear-gradient(#59b9ff,#0a63e8)" url="https://www.google.com"
    desc="Ketik alamat situs atau kata kunci. Hasilnya dibuka di tab baru." placeholder="Cari atau ketik alamat web"
    search={smart}
    links={[
      ['Google', 'https://www.google.com'],
      ['Wikipedia Indonesia', 'https://id.wikipedia.org'],
      ['GitHub', 'https://github.com']
    ]} />
)
