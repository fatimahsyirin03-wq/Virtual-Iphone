import { useState, useEffect, useRef } from 'react'
import { APPS, DOCK } from './apps.jsx'
import { Ctx } from './ctx.js'
import { useLocal, useNow } from './hooks.js'
import { WALLPAPERS, PHOTO_SEED } from './data.js'

const DEFAULTS = { dark: false, wifi: true, bt: true, air: false, wall: 0, bright: 100, name: 'iPhone Virtual' }
const clock = (d) => d.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', hour12: false }).replace('.', ':')

function Bar({ now, s, light }) {
  return (
    <div className={`status ${light ? '' : 'dk'}`}>
      <span>{clock(now)}</span>
      <span className="sicons">
        {s.air ? (
          <span>✈</span>
        ) : (
          <>
            <svg width="18" height="12" viewBox="0 0 18 12" fill="currentColor">
              <rect x="0" y="8" width="3" height="4" rx="1" />
              <rect x="5" y="5" width="3" height="7" rx="1" />
              <rect x="10" y="2" width="3" height="10" rx="1" />
              <rect x="15" y="0" width="3" height="12" rx="1" />
            </svg>
            {s.wifi && (
              <svg width="16" height="12" viewBox="0 0 16 12" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
                <path d="M1 4a10 10 0 0 1 14 0M3.5 7a6.5 6.5 0 0 1 9 0" />
                <circle cx="8" cy="10.5" r="1" fill="currentColor" />
              </svg>
            )}
          </>
        )}
        <svg width="26" height="12" viewBox="0 0 26 12">
          <rect x=".5" y=".5" width="22" height="11" rx="3.5" fill="none" stroke="currentColor" opacity=".5" />
          <rect x="2" y="2" width="19" height="8" rx="2" fill="currentColor" />
          <rect x="24" y="4" width="2" height="4" rx="1" fill="currentColor" opacity=".5" />
        </svg>
      </span>
    </div>
  )
}

function Icon({ a, now, onClick, nolabel }) {
  return (
    <button className="icon" onClick={onClick} aria-label={a.name}>
      <span className="tile" style={{ background: a.bg }}>
        {a.id === 'calendar' ? (
          <span className="cal">
            <i>{now.toLocaleDateString('id-ID', { weekday: 'short' })}</i>
            <b>{now.getDate()}</b>
          </span>
        ) : (
          a.glyph
        )}
      </span>
      {!nolabel && <em>{a.name}</em>}
    </button>
  )
}

export default function App() {
  const [raw, setRaw] = useLocal('vi-settings', DEFAULTS)
  const s = { ...DEFAULTS, ...raw }
  const set = (k, v) => setRaw((p) => ({ ...p, [k]: v }))
  const [photos, setPhotos] = useState(PHOTO_SEED)
  const [locked, setLocked] = useState(true)
  const [openId, setOpenId] = useState(null)
  const [closing, setClosing] = useState(false)
  const startY = useRef(null)
  const now = useNow()
  const cur = APPS.find((a) => a.id === openId)

  const open = (id) => { setClosing(false); setOpenId(id) }
  const close = () => {
    if (!openId || closing) return
    setClosing(true)
    setTimeout(() => { setOpenId(null); setClosing(false) }, 260)
  }
  const reset = () => {
    try {
      Object.keys(localStorage).filter((k) => k.startsWith('vi-')).forEach((k) => localStorage.removeItem(k))
    } catch {}
    location.reload()
  }

  useEffect(() => {
    const h = (e) => {
      if (e.key === 'Escape') close()
      if (e.key === 'Enter' && locked) setLocked(false)
    }
    window.addEventListener('keydown', h)
    return () => window.removeEventListener('keydown', h)
  })

  const light = locked || !cur || cur.dark || s.dark

  return (
    <Ctx.Provider value={{ s, set, photos, setPhotos, reset, close }}>
      <div className="stage">
        <div className="phone" data-theme={s.dark ? 'dark' : 'light'} style={{ filter: `brightness(${0.4 + (s.bright / 100) * 0.6})` }}>
          <div className="wall" style={{ background: WALLPAPERS[s.wall].css }} />
          <Bar now={now} s={s} light={light} />
          <div className="island" />

          <div className={`home ${cur && !closing ? 'back' : ''}`}>
            <div className="widget">
              <div className="wd">{now.toLocaleDateString('id-ID', { weekday: 'long' })}</div>
              <div className="wn">{now.getDate()} {now.toLocaleDateString('id-ID', { month: 'long' })}</div>
              <div className="ws">{s.name}</div>
            </div>
            <div className="grid">
              {APPS.filter((a) => !DOCK.includes(a.id)).map((a) => (
                <Icon key={a.id} a={a} now={now} onClick={() => open(a.id)} />
              ))}
            </div>
            <div className="dock">
              {DOCK.map((id) => {
                const a = APPS.find((x) => x.id === id)
                return <Icon key={id} a={a} now={now} nolabel onClick={() => open(id)} />
              })}
            </div>
          </div>

          {cur && (
            <div className={`app ${closing ? 'out' : 'in'} ${cur.dark ? 'force-dark' : ''}`}>
              <cur.Comp />
            </div>
          )}

          <div
            className={`lock ${locked ? '' : 'gone'}`}
            onClick={() => setLocked(false)}
            onPointerDown={(e) => (startY.current = e.clientY)}
            onPointerUp={(e) => {
              if (startY.current !== null && startY.current - e.clientY > 50) setLocked(false)
              startY.current = null
            }}
          >
            <div className="ldate">{now.toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' })}</div>
            <div className="ltime">{clock(now)}</div>
            <div className="lcard">
              <b>Selamat datang 👋</b>
              <span>Ini simulasi iPhone untuk demo. Tidak terhubung ke akun atau data asli.</span>
            </div>
            <div className="lhint">Geser ke atas atau ketuk untuk membuka</div>
          </div>

          <button className={`indicator ${light ? '' : 'dk'}`} aria-label="Beranda" onClick={() => (cur ? close() : setLocked(true))} />
        </div>
      </div>
    </Ctx.Provider>
  )
}
