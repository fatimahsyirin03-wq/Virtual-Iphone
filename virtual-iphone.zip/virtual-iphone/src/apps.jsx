import { Messages, Notes, Gallery, Settings, Calendar, Phone, Camera } from './apps/Demo.jsx'
import { WhatsApp, Instagram, XApp, Spotify, YouTube, Maps, Safari } from './apps/External.jsx'

// Glyph memakai emoji generik (bukan logo resmi merek).
export const APPS = [
  { id: 'whatsapp', name: 'WhatsApp', glyph: '💬', bg: 'linear-gradient(#5ff07e,#1fae4b)', Comp: WhatsApp },
  { id: 'instagram', name: 'Instagram', glyph: '📸', bg: 'linear-gradient(45deg,#feda75,#fa7e1e 25%,#d62976 50%,#962fbf 75%,#4f5bd5)', Comp: Instagram },
  { id: 'x', name: 'X', glyph: '𝕏', bg: '#000', Comp: XApp, dark: true },
  { id: 'spotify', name: 'Spotify', glyph: '🎧', bg: 'linear-gradient(#1ed760,#118a3c)', Comp: Spotify, dark: true },
  { id: 'youtube', name: 'YouTube', glyph: '▶️', bg: 'linear-gradient(#ff4e45,#c4150c)', Comp: YouTube },
  { id: 'maps', name: 'Maps', glyph: '🗺️', bg: 'linear-gradient(#6ee7a0,#4aa3ff)', Comp: Maps },
  { id: 'photos', name: 'Foto', glyph: '🌸', bg: 'linear-gradient(135deg,#fff,#eee)', Comp: Gallery },
  { id: 'notes', name: 'Catatan', glyph: '📝', bg: 'linear-gradient(#ffe066,#f5b800)', Comp: Notes },
  { id: 'calendar', name: 'Kalender', glyph: '📅', bg: '#fff', Comp: Calendar },
  { id: 'settings', name: 'Pengaturan', glyph: '⚙️', bg: 'linear-gradient(#a9adb5,#6b6f78)', Comp: Settings },
  { id: 'safari', name: 'Safari', glyph: '🧭', bg: 'linear-gradient(#59b9ff,#0a63e8)', Comp: Safari },
  { id: 'messages', name: 'Pesan', glyph: '✉️', bg: 'linear-gradient(#5fe27a,#1fae4b)', Comp: Messages },
  { id: 'phone', name: 'Telepon', glyph: '📞', bg: 'linear-gradient(#5fe27a,#1fae4b)', Comp: Phone },
  { id: 'camera', name: 'Kamera', glyph: '📷', bg: 'linear-gradient(#d0d0d4,#8e8e93)', Comp: Camera, dark: true }
]

export const DOCK = ['phone', 'safari', 'messages', 'camera']
