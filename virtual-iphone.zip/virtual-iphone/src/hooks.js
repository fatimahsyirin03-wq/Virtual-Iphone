import { useState, useEffect } from 'react'

// useState yang disimpan di localStorage (hanya di browser pengguna)
export function useLocal(key, init) {
  const [v, setV] = useState(() => {
    try {
      const x = localStorage.getItem(key)
      return x ? JSON.parse(x) : init
    } catch {
      return init
    }
  })
  useEffect(() => {
    try {
      localStorage.setItem(key, JSON.stringify(v))
    } catch {}
  }, [key, v])
  return [v, setV]
}

export function useNow() {
  const [n, setN] = useState(new Date())
  useEffect(() => {
    const t = setInterval(() => setN(new Date()), 1000)
    return () => clearInterval(t)
  }, [])
  return n
}
